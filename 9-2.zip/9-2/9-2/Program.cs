﻿using System;
using System.IO;
using lab9.Ser;
using ProtoBuf;

[ProtoContract]
[Serializable]
[ProtoInclude(1, typeof(Student))]
public class Person
{
    private string family;
    [ProtoMember(2)]
    public string Family { get { return family; } set { family = value; } }
    public Person() { }
    public Person(string family1)
    {
        family = family1;
    }
}
[ProtoContract]
[Serializable]
public class Student : Person
{
    private static int id;
    private int number;
    [ProtoMember(3)]
    public int Number { get { return number; } set { number = value; } }
    private double rez1, rez2, rez3, rez4;
    private double rez;
    private double sr(double x, double y, double z, double w)
    {
        return (x + y + z + w) / 4;
    }
    [ProtoMember(4)]
    public double Rez { get { return rez; } set { rez = value; } }
    public Student() { }
    public Student(string family, double rezz1, double rezz2, double rezz3, double rezz4) : base(family)
    {
        rez = 0;
        rez1 = rezz1;
        rez2 = rezz2;
        rez3 = rezz3;
        rez4 = rezz4;
        rez = sr(rez1, rez2, rez3, rez4);
        number = Convert.ToInt32($"2305{id}");
        id++;
    }
    public void DisplayInfo()
    {
        Console.WriteLine("Фамилия {0}\t Номер студ билета {1}\t Средний балл {2,4:f2}", Family, number, Rez);
    }
}

class Program
{
    static void Main(string[] args)
    {
        Student[] os = new Student[4];
        os[0] = new Student("Умкин", 3.0, 4.0, 5.0, 4.0);
        os[1] = new Student("Пупкин", 4.0, 5.0, 3.0, 5.0);
        os[2] = new Student("Лупкин", 3.0, 3.0, 4.0, 5.0);
        os[3] = new Student("Зупкин", 5.0, 5.0, 5.0, 5.0);

        //foreach (var student in os)
        //{
        //    student.DisplayInfo();
        //}

        for (int i = 0; i < os.Length - 1; i++)
        {
            double amax = os[i].Rez;
            int imax = i;
            for (int j = i + 1; j < os.Length; j++)
            {
                if (os[j].Rez > amax)
                {
                    amax = os[j].Rez;
                    imax = j;
                }
            }
            Student temp;
            temp = os[imax];
            os[imax] = os[i];
            os[i] = temp;
        }

        Console.WriteLine();

        //foreach (var student in os)
        //{
        //    if (student.Rez >= 4)
        //    {
        //        student.DisplayInfo();
        //    }
        //}
        ISer[] serializers = new ISer[]
        {
            new MySerializeJson(),
            new MySerializeXML(),
            new MySerializeBin()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Students";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[]
        {
            "students.json",
            "students.xml",
            "students.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(os, Path.Combine(path, files[i]));

        }
        for (int i = 0; i < serializers.Length; i++)
        {
            Console.WriteLine(i+1);
            os = serializers[i].Read<Student[]>(Path.Combine(path, files[i]));
            foreach (Student student in os)
            {
                student.DisplayInfo();
            }
        }
        Console.ReadKey();
    }
}
