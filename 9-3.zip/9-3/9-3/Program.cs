﻿using System;
using System.Collections.Generic;
using System.Linq;
using lab9.Ser;
using ProtoBuf;

[ProtoContract]
[Serializable]
[ProtoInclude(1, typeof(BBI_23_4_Student))]
[ProtoInclude(2, typeof(BBI_23_5_Student))]
[ProtoInclude(3, typeof(BBI_23_6_Student))]
public class Group_Student
{
    protected double sum;
    [ProtoMember(4)]
    public double Sum { get { return sum; } set { sum = value; } }
    protected int count;
    [ProtoMember(5)]
    public int Count { get { return count; } set { count = value; } }
    [ProtoMember(6)]
    public string group_name { get; set; }
    protected string surname;
    [ProtoMember(7)]
    public string Surname { get { return surname; } set { surname = value; } }
    protected double mark1, mark2, mark3, mark4;
    [ProtoMember(8)]
    public virtual double[] Marks { get { return new double[] { mark1, mark2, mark3, mark4 }; } }
    public virtual double AverageMark()
    {
        return (mark1 + mark2 + mark3 + mark4) / 4;
    }
    public Group_Student() { }
    public Group_Student(string surname, double mark1, double mark2, double mark3, double mark4)
    {
        this.surname = surname;
        this.mark1 = mark1;
        this.mark2 = mark2;
        this.mark3 = mark3;
        this.mark4 = mark4;
        group_name = "-";
    }
    public virtual double getAVG()
    {
        return sum / count;
    }
    public void PrintInfo()
    {
        Console.WriteLine(surname + " " + getAVG());
    }
}
[ProtoContract]
[Serializable]
public class BBI_23_4_Student : Group_Student
{
    private double math, physics;
    [ProtoMember(9)]
    public override double[] Marks { get { return new double[] { mark1, mark2, mark3, mark4, math, physics }; } }
    public BBI_23_4_Student() { }
    public BBI_23_4_Student(string surname, double mark1, double mark2, double mark3, double mark4, double math, double physics) : base(surname, mark1, mark2, mark3, mark4)
    {
        this.math = math;
        this.physics = physics;
        sum += AverageMark();
        count++;
        group_name = "BBI_23_4";
    }
    public override double AverageMark()
    {
        return (mark1 + mark2 + mark3 + mark4 + math + physics) / 6;
    }
    public override double getAVG()
    {
        return sum / count;
    }
}
[ProtoContract]
[Serializable]
public class BBI_23_5_Student : Group_Student
{
    private double PE, chemistry;
    [ProtoMember(10)]
    public override double[] Marks { get { return new double[] { mark1, mark2, mark3, mark4, PE, chemistry }; } }
    public BBI_23_5_Student() { }
    public BBI_23_5_Student(string surname, double mark1, double mark2, double mark3, double mark4, double PE, double chemistry) : base(surname, mark1, mark2, mark3, mark4)
    {
        this.PE = PE;
        this.chemistry = chemistry;
        sum += AverageMark();
        count++;
        group_name = "BBI-23-5";
    }
    public override double AverageMark()
    {
        return (mark1 + mark2 + mark3 + mark4 + PE + chemistry) / 6;
    }
    public override double getAVG()
    {
        return sum / count;
    }
}
[ProtoContract]
[Serializable]
public class BBI_23_6_Student : Group_Student
{
    private double english, spanish;
    [ProtoMember(11)]
    public override double[] Marks { get { return new double[] { mark1, mark2, mark3, mark4, english, spanish }; } }
    public BBI_23_6_Student() { }
    public BBI_23_6_Student(string surname, double mark1, double mark2, double mark3, double mark4, double english, double spanish) : base(surname, mark1, mark2, mark3, mark4)
    {
        this.english = english;
        this.spanish = spanish;
        sum += AverageMark();
        count++;
        group_name = "BBI-23-6";
    }
    public override double AverageMark()
    {
        return (mark1 + mark2 + mark3 + mark4 + english + spanish) / 6;
    }
    public override double getAVG()
    {
        return sum / count;
    }
}

class Program
{
    static void Main(string[] args)
    {
        BBI_23_4_Student[] bbi_23_4 =
        {
            new BBI_23_4_Student("Васильев",5.0, 5.0, 4.0, 5.0, 3.0, 4.0),
            new BBI_23_4_Student("Иванов", 4.0, 4.0, 3.0, 4.0, 2.0, 3.0),
            new BBI_23_4_Student("Доржиев", 5.0, 4.0, 5.0, 5.0, 4.0, 5.0)
        };
        BBI_23_5_Student[] bbi_23_5 =
        {
            new BBI_23_5_Student("Цоктоев", 5.0, 4.0, 3.0, 5.0, 5.0, 4.0),
            new BBI_23_5_Student("Гатапов", 4.0, 3.0, 2.0, 3.0, 3.0, 4.0),
            new BBI_23_5_Student("Лыпкин", 5.0, 4.0, 3.0, 3.0, 3.0, 5.0)
        };
        BBI_23_6_Student[] bbi_23_6 =
        {
            new BBI_23_6_Student("Харханов", 5.0, 5.0, 5.0, 5.0, 5.0, 5.0),
            new BBI_23_6_Student("Жамсоев", 4.0, 4.0, 4.0, 4.0, 4.0, 3.0),
            new BBI_23_6_Student("Игумнов", 4.0, 5.0, 5.0, 3.0, 4.0, 5.0)
        };

        Group_Student[] groups = new Group_Student[bbi_23_4.Length + bbi_23_5.Length + bbi_23_6.Length];
        for (int i = 0; i < bbi_23_4.Length; i++)
        {
            groups[i] = bbi_23_4[i];
        }
        for (int i = 0; i < bbi_23_5.Length; i++)
        {
            groups[bbi_23_4.Length + i] = bbi_23_5[i];
        }
        for (int i = 0; i < bbi_23_6.Length; i++)
        {
            groups[bbi_23_4.Length + bbi_23_5.Length + i] = bbi_23_6[i];
        }

        Dictionary<string, double> averages = new Dictionary<string, double>();
        for (int i = 0; i < groups.GetLength(0); i++)
        {
            if (averages.ContainsKey(groups[i].group_name)) { }
            else
            {
                averages.Add(groups[i].group_name, groups[i].getAVG());
            }
        }
        var sortedAverages = averages.OrderByDescending(x => x.Value);
        //Console.WriteLine("Group");
        //foreach (var item in sortedAverages)
        //{
        //    Console.WriteLine($"{item.Key}\t\t{item.Value:F2}");
        //}
        ISer[] serializers = new ISer[]
        {
            new MySerializeJson(),
            new MySerializeXML(),
            new MySerializeBin()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Students";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[]
        {
                "students.json",
                "students.xml",
                "students.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(bbi_23_6, Path.Combine(path, files[i]));
        }
        for (int i = 0; i < serializers.Length; i++)
        {
            Console.WriteLine(i + 1);
            bbi_23_6 = serializers[i].Read<BBI_23_6_Student[]>(Path.Combine(path, files[i]));
            foreach (BBI_23_6_Student student in bbi_23_6)
            {
                student.PrintInfo();
            }
        }
        Console.ReadKey();
    }
}

