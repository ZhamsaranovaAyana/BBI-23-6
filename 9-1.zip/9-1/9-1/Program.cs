﻿//#1
using System;
using System.Collections.Generic;
using System.Linq;
using ProtoBuf;
using lab9.Ser;
using System.Text.Json;
using System.IO;


class Program
{
    static void Main(string[] args)
    {
        List<Run_500m> run500 = new List<Run_500m>();

        run500.Add(new Run_500m("Иванова", "Группа 1", "Тренер Ларкова", 120));
        run500.Add(new Run_500m("Петрова", "Группа 2", "Тренер Паркова", 110));
        run500.Add(new Run_500m("Сидорова", "Группа 1", "Тренер Жаркова", 100));
        run500.Add(new Run_500m("Смирнова", "Группа 3", "Тренер Маркова", 90));

        //Console.WriteLine("Результаты кросса на 500м:");
        //Console.WriteLine("Фамилия\t\t Группа \t\t Преподаватель \t\t Результат в секундах \t\t Норматив");

        //foreach (var runner in run500.OrderBy(runner => runner.Result))
        //{
        //    runner.DisplayInfo();
        //}

        //int passedNorm = run500.Count(runner => runner.Result <= 100);
        //Console.WriteLine($"\nОбщее количество участниц, выполнивших норматив: {passedNorm}");

        List<Run_100m> run100 = new List<Run_100m>();

        run100.Add(new Run_100m("Иванова", "Группа 1", "Тренер Ларкова", 11));
        run100.Add(new Run_100m("Петрова", "Группа 2", "Тренер Паркова", 7));
        run100.Add(new Run_100m("Сидорова", "Группа 1", "Тренер Жаркова", 13));
        run100.Add(new Run_100m("Смирнова", "Группа 3", "Тренер Маркова", 8));

        //Console.WriteLine("Результаты кросса на 100м:");
        //Console.WriteLine("Фамилия\t\t Группа \t\t Преподаватель \t\t Результат в секундах \t\t Норматив");

        //foreach (var runner in run100.OrderBy(runner => runner.Result))
        //{
        //    runner.DisplayInfo();
        //}

        //passedNorm = run100.Count(runner => runner.Result <= 100);
        //Console.WriteLine($"\nОбщее количество участниц, выполнивших норматив: {passedNorm}");
        ISer[] serializers = new ISer[]
        {
            new MySerializeJson(),
            new MySerializeXML(),
            new MySerializeBin()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Runners";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path)) Directory.CreateDirectory(path);
        string[] files = new string[]
        {
                "runners.json",
                "runners.xml",
                "runners.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(run100, Path.Combine(path, files[i]));

        }
        for (int i = 0; i < serializers.Length; i++)
        {
            Console.WriteLine(i+1);
            run100 = serializers[i].Read<List<Run_100m>>(Path.Combine(path, files[i]));
            foreach (Run_100m runner in run100)
            {
                runner.DisplayInfo();
            }
        }

        Console.ReadKey();
    }
    public static void SortWords(string[] words)
    {
        int n = words.Length;

        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                if (CompareWords(words[j], words[j + 1]) > 0)
                {
                    string temp = words[j];
                    words[j] = words[j + 1];
                    words[j + 1] = temp;
                }
            }
        }
    }
    public static int CompareWords(string word1, string word2)
    {
        int minLength = Math.Min(word1.Length, word2.Length);

        for (int i = 0; i < minLength; i++)
        {
            if (word1[i] < word2[i])
                return -1;
            if (word1[i] > word2[i])
                return 1;
        }
        if (word1.Length < word2.Length)
            return -1;
        if (word1.Length > word2.Length)
            return 1;
        return 0;
    }
}
[ProtoContract]
[Serializable]
[ProtoInclude(1, typeof(Run_100m))]
[ProtoInclude(2, typeof(Run_500m))]
public abstract class Runner
{
    [ProtoMember(3)]
    public string Surname { get; set; }
    [ProtoMember(4)]
    public string Group { get; set; }
    [ProtoMember(5)]
    public string TeacherSurname { get; set; }
    [ProtoMember(6)]
    public double Result { get; set; }
    public Runner() { }
    public Runner(string surname, string group, string teacherSurname, double result)
    {
        Surname = surname;
        Group = group;
        TeacherSurname = teacherSurname;
        Result = result;
    }

    public virtual void DisplayInfo()
    {
        Console.WriteLine($"{Surname}\t\t{Group}\t\t{TeacherSurname}\t\t{Result}");
    }
}
[ProtoContract]
[Serializable]
public class Run_500m : Runner
{
    public Run_500m() { }
    public Run_500m(string Surname, string Group, string TeacherSurname, double Result) : base(Surname, Group, TeacherSurname, Result)
    {
    }
    public override void DisplayInfo()
    {
        Console.WriteLine($"{Surname}\t\t{Group}\t\t{TeacherSurname}\t\t{Result:F2}\t\t{(Result <= 100 ? "Выполнен" : "Не выполнен")}");
    }
}
[ProtoContract]
[Serializable]
public class Run_100m : Runner
{
    public Run_100m() { }
    public Run_100m(string Surname, string Group, string TeacherSurname, double Result) : base(Surname, Group, TeacherSurname, Result)
    {
    }
    public override void DisplayInfo()
    {
        Console.WriteLine($"{Surname}\t\t{Group}\t\t{TeacherSurname}\t\t{Result:F2}\t\t{(Result <= 10 ? "Выполнен" : "Не выполнен")}");
    }
}
